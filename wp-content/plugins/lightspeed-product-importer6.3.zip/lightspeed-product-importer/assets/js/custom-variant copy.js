jQuery(function ($) {
    let fieldCounter = 0;
    // Modular Field Generators
    function createInputField(fieldName, inputId) {
        return `
        <div class="input_container">
            <div class="input_heading">
                <input type="hidden" name="field_name" value="${fieldName}" data-field_type="text">
                <p class="input-type">Input Type: Text</p>
                <div class="required-checkbox-wrapper">
                    <input type="checkbox" id="${inputId}" name="required">
                    <label for="${inputId}">Required</label>
                </div>
                <button class="delete-input-btn" title="Delete Input">×</button>
            </div>
            <div class="model-body">
                <input type="text" name="heading" class="heading-text" placeholder="Heading">
            </div>
        </div>`;
    }

    function createTextareaField(fieldName, inputId) {
        return `
        <div class="input_container">
            <div class="input_heading">
                <input type="hidden" name="field_name" value="${fieldName}" data-field_type="textarea">
                <p class="input-type">Input Type: Textarea</p>
                <div class="required-checkbox-wrapper">
                    <input type="checkbox" id="${inputId}" name="required">
                    <label for="${inputId}">Required</label>
                </div>
                <button class="delete-input-btn" title="Delete Input">×</button>
            </div>
            <div class="model-body">
                <input type="text" name="heading" class="heading-text" placeholder="Heading">
            </div>
        </div>`;
    }

    function createRadioField(fieldName, inputId) {
        return `
        <div class="input_container">
            <div class="input_heading">
            <input type="hidden" name="field_name" value="${fieldName}" data-field_type="radio">
                <p class="input-type">Input Type: Radio</p>
                <div class="required-checkbox-wrapper">
                    <input type="checkbox" id="${inputId}" name="required">
                    <label for="${inputId}">Required</label>
                </div>
                <button class="delete-input-btn" title="Delete Input">×</button>
            </div>
            <div class="model-body">
                <input type="text" name="heading" class="heading-text" placeholder="Heading">
                <div class="option_list">
                    ${createOptionRow()}
                </div>
                <button type="button" class="custom-btn add-option-btn" style="margin-top: 5px;">Add Option</button>
            </div>
        </div>`;
    }

    function createSelectField(fieldName, inputId) {
        return `
        <div class="input_container">
            <div class="input_heading">
                <input type="hidden" name="field_name" value="${fieldName}" data-field_type="select">
                <p class="input-type">Input Type: Select</p>
                <div class="required-checkbox-wrapper">
                    <input type="checkbox" id="${inputId}" name="required">
                    <label for="${inputId}">Required</label>
                </div>
                <button class="delete-input-btn" title="Delete Input">×</button>
            </div>
            <div class="model-body">
                <input type="text" name="heading" class="heading-text" placeholder="Heading">
                <div class="option_list">
                    ${createOptionRow()}
                </div>
                <button type="button" class="custom-btn add-option-btn" style="margin-top: 5px;">Add Option</button>
            </div>
        </div>`;
    }

    function createOptionRow() {
        return `
        <div class="option-row">
            <input type="text" placeholder="Option heading">
            <input type="number" name="price" placeholder="Price">
            <button type="button" class="delete-btn">×</button>
        </div>`;
    }

    $('.add_input_btn').on('click', function () {
        const type = $(this).closest('.woocommerce_options_panel').find('.input_type').val();
        if (!type) return;

        fieldCounter++;
        const fieldName = 'field_' + Date.now() + fieldCounter;
        const inputId = 'required_' + Date.now() + fieldCounter;
        console.log("type", type, fieldName, inputId)
        let inputBlock = '';

        switch (type) {
            case 'text':
                inputBlock = createInputField(fieldName, inputId);
                break;
            case 'textarea':
                inputBlock = createTextareaField(fieldName, inputId);
                break;
            case 'radio':
                inputBlock = createRadioField(fieldName, inputId);
                break;
            case 'select':
                inputBlock = createSelectField(fieldName, inputId);
                break;
            default:
                return;
        }
        $(this).closest('.woocommerce_options_panel').find('.input_wrapper').append(inputBlock);
    });

    // Option row addition
    $(document).on('click', '.add-option-btn', function () {
        $(this).siblings('.option_list').append(createOptionRow());
    });

    // Option row deletion
    $(document).on('click', '.delete-btn', function () {
        $(this).closest('.option-row').remove();
    });

    // Input container deletion
    $(document).on('click', '.delete-input-btn', function (e) {
        e.preventDefault();
    
        // Remove from the DOM
        $(this).closest('.input_container').remove();
    
        // Re-serialize and update hidden input + table
        const allFields = [];
    
        $('.input_container').each(function () {
            const container = $(this);
            const name = container.find('input[name="field_name"]').val();
            const type = container.find('input[name="field_name"]').data('field_type');
            const required = container.find('input[name="required"]').is(':checked');
            const heading = container.find('input[name="heading"]').val() || '';
    
            const field = {
                name: name,
                type: type,
                required: required,
                heading: heading
            };

            console.log("field", field);
    
            if (type === 'radio' || type === 'select') {
                const values = [];
                container.find('.option_list .option-row').each(function () {
                    const row = $(this);
                    const heading = row.find('input[type="text"]').val() || '';
                    const price = row.find('input[name="price"]').val() || '';
                    values.push({ heading, price });
                });
                field.values = values;
            }
    
            allFields.push(field);
        });

        console.log(allFields , "ocean");
    
        // Update hidden input and table
        $('#custom_variants_data').val(JSON.stringify(allFields));
        renderVariantTable(allFields);
    });
    
    $(document).on('click', '.edit_btn', function (e) {
        e.preventDefault();
        const mainDiv = $(this).closest('.woocommerce_options_panel');
        mainDiv.find('.main-model').fadeIn();
    
        // Get the saved data
        const fields = typeof customVariantData !== 'undefined' ? customVariantData.variants : JSON.parse($('#custom_variants_data').val());
        const inputWrapper = mainDiv.find('.input_wrapper');
        // Clear modal content
        inputWrapper.empty();
        
        console.log("fields", fields)
        // Loop through each field and append it
        fields.forEach((field, index) => {
            const inputId = Date.now() + '_' + index;
            let html = '';
            switch (field.type) {
                case 'text':
                    html = createInputField(field.name, inputId);
                    break;
                case 'textarea':
                    html = createTextareaField(field.name, inputId);
                    break;
                case 'radio':
                    html = createRadioField(field.name, inputId);
                    break;
                case 'select':
                    html = createSelectField(field.name, inputId);
                    break;
            }
    
            // Append the field to wrapper
            inputWrapper.append(html);
    
            // Now populate the values for the latest appended element
            const container = inputWrapper.find('.input_container').last();
            container.find('input[name="field_name"]').val(field.name);
            container.find('input[name="heading"]').val(field.heading);
            if (field.required) {
                container.find('input[name="required"]').prop('checked', true);
            }
    
            // If it has values (radio or select), populate them
            if ((field.type.toLowerCase() === 'radio' || field.type.toLowerCase() === 'select') && field.values) {
                const optionList = container.find('.option_list');
                optionList.empty(); // remove default option row
    
                field.values.forEach(opt => {
                    const row = $(createOptionRow());
                    row.find('input[type="text"]').val(opt.heading);
                    row.find('input[name="price"]').val(opt.price);
                    optionList.append(row);
                });
            }
        });
    });

    // Modal open/close
    $('.close_Btn').on('click', function () {
        $(this).closest('.main-model').hide();
    });

    // Show the modal for the related section
    $('.add_btn').on('click', function() {
        $(this).closest('.woocommerce_options_panel').find('.main-model').fadeIn();
    });

    $('.save_input_btn').on('click', function () {
        const allFields = [];
        const inputWrapper = $(this).closest('.woocommerce_options_panel').find('.input_wrapper');
            console.log("inputWrapper", inputWrapper.html());
            inputWrapper.find('.input_container').each(function () {
            const container = $(this);
            const name = container.find('input[name="field_name"]').val();
            const type = container.find('input[name="field_name"]').data('field_type');
            const required = container.find('input[name="required"]').is(':checked');
            const heading = container.find('input[name="heading"]').val() || '';
    
            const field = {
                name: name,
                type: type.toLowerCase(),
                isRequired: required,
                heading: heading
            };
    
            if (type === 'radio' || type === 'select') {
                const values = [];
                container.find('.option_list .option-row').each(function () {
                    const row = $(this);
                    const heading = row.find('input[type="text"]').val() || '';
                    const price = row.find('input[name="price"]').val() || '';
                    if (heading !== '' || price !== '') {
                        values.push({
                            heading: heading,
                            price: price
                        });
                    }
                });
                field.values = values;
            }
    
            allFields.push(field);
        });
        console.log("allFields", allFields);
        // Save data into hidden input
        $('#custom_variants_data').val(JSON.stringify(allFields));

        // Show in table format
        renderVariantTable(allFields);

        //hide model
        inputWrapper.closest('.main-model').hide();
    });
    alert("5434")
    console.log("ocean", customVariantData)
    if (typeof customVariantData !== 'undefined' && customVariantData.variants !== null) {
        console.log("customVariantData", customVariantData)
        renderVariantTable(customVariantData.variants);
    }

    function renderVariantTable(data) {
        let html = '<table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; width: 100%;">';
        html += '<thead><tr><th>Type</th><th>Required</th><th>Heading</th><th>values</th></tr></thead><tbody>';
        console.log(data,"ocean");
        data.forEach((field, index) => {
            html += `<tr data-index="${index}">
                <td>${field.type}</td>
                <td>${field.isRequired ? 'Yes' : 'No'}</td>
                <td>${field.heading}</td>`;
    
            if (field.values && field.values.length) {
                html += `<td><ul style="margin: 0; padding-left: 15px;">`;
                field.values.forEach(opt => {
                    html += `<li><strong>${opt.heading}</strong> (Price: € ${opt.price})</li>`;
                });
                html += `</ul></td>`;
            } else {
                html += `<td>—</td>`;
            }
        });
    
        html += '</tbody></table>';
        $('#variant_table').html(html);
    }

    // if (typeof customFieldsData !== 'undefined' && customFieldsData.fields.length > 0) {
    //     console.log("customFieldsData", customFieldsData)
    //     renderVariantTable(customFieldsData.fields);
    // }

    $(document).on('click', '.edit_field_btn', function () {
        const mainDiv = $(this).closest('.woocommerce_options_panel');
        mainDiv.find('.main-model').fadeIn();
    
        // Get the saved data
        const fields = typeof customFieldsData !== 'undefined' ? customFieldsData.fields : JSON.parse($('#custom_fields_data').val());
        const inputWrapper = mainDiv.find('.input_wrapper');
        // Clear modal content
        inputWrapper.empty();
        
        console.log("fields", fields)
        // Loop through each field and append it
        fields.forEach((field, index) => {
            const inputId = Date.now() + '_' + index;
            let html = '';
            switch (field.type) {
                case 'text':
                    html = createInputField(field.name, inputId);
                    break;
                case 'textarea':
                    html = createTextareaField(field.name, inputId);
                    break;
                case 'radio':
                    html = createRadioField(field.name, inputId);
                    break;
                case 'select':
                    html = createSelectField(field.name, inputId);
                    break;
            }
    
            // Append the field to wrapper
            inputWrapper.append(html);
    
            // Now populate the values for the latest appended element
            const container = inputWrapper.find('.input_container').last();
            container.find('input[name="field_name"]').val(field.name);
            container.find('input[name="heading"]').val(field.heading);
            if (field.required) {
                container.find('input[name="required"]').prop('checked', true);
            }
    
            // If it has values (radio or select), populate them
            if ((field.type.toLowerCase() === 'radio' || field.type.toLowerCase() === 'select') && field.values) {
                const optionList = container.find('.option_list');
                optionList.empty(); // remove default option row
    
                field.values.forEach(opt => {
                    const row = $(createOptionRow());
                    row.find('input[type="text"]').val(opt.heading);
                    row.find('input[name="price"]').val(opt.price);
                    optionList.append(row);
                });
            }
        });
    });

    $('.save_field_btn').on('click', function () {
        const allFields = [];
        const inputWrapper = $(this).closest('.woocommerce_options_panel').find('.input_wrapper');
            console.log("inputWrapper", inputWrapper.html());
            inputWrapper.find('.input_container').each(function () {
            const container = $(this);
            const name = container.find('input[name="field_name"]').val();
            const type = container.find('input[name="field_name"]').data('field_type');
            const required = container.find('input[name="required"]').is(':checked');
            const heading = container.find('input[name="heading"]').val() || '';
    
            const field = {
                name: name,
                type: type.toLowerCase(),
                isRequired: required,
                heading: heading
            };
    
            if (type === 'radio' || type === 'select') {
                const values = [];
                container.find('.option_list .option-row').each(function () {
                    const row = $(this);
                    const heading = row.find('input[type="text"]').val() || '';
                    const price = row.find('input[name="price"]').val() || '';
                    if (heading !== '' || price !== '') {
                        values.push({
                            heading: heading,
                            price: price
                        });
                    }
                });
                field.values = values;
            }
    
            allFields.push(field);
        });
        console.log("allFields", allFields);
        // Save data into hidden input
        $('#custom_fields_data').val(JSON.stringify(allFields));

        // Show in table format
        renderVariantTable(allFields);

        //hide model
        inputWrapper.closest('.main-model').hide();
    });
    
});
